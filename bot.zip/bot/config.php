<?php
// Bot token from @BotFather
define("BOT_TOKEN", "8500039166:AAEw2XMF_Sv1fg-61Ap_aEysm_kJVNrn_I4");

// Channel username (must start with @)
define("CHANNEL_USERNAME", "@J4ckofficial");

// Admin Telegram user ID
define("ADMIN_ID", "5322998438");

// Path to user data file
define("USER_FILE", __DIR__ . "/users.json");

// Path to key file
define("KEY_FILE", __DIR__ . "/key.txt");